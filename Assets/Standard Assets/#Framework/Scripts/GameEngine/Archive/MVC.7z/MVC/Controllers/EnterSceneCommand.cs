﻿using GameEngine.GameKit.MVC.Kernel;
using GameEngine.GameKit.MVC.Kernel.Consts;
using GameEngine.GameKit.MVC.Views;

namespace GameEngine.GameKit.MVC.Controllers {

public class EnterSceneCommand : Controller<EnterSceneCommand> {

    public override void Execute(object data)
    {
        var e = data as E_EnterScene;

        switch( e.sceneIndex ) {
            case 0 : // Init
                break;
            case 1 :
                RegisterView(FindObjectOfType<UILevel>());
                RegisterView(FindObjectOfType<UITitle>());

                break;
        }
    }

}

}
