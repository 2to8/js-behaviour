﻿namespace GameEngine.GameKit.MVC.Contacts {

public interface IEvent { }

}
