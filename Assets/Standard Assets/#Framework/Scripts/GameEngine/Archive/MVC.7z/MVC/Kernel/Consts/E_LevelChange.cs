﻿namespace GameEngine.GameKit.MVC.Kernel.Consts {

public class E_LevelChange {

    public int level;

}

}
