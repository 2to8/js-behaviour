﻿using GameEngine.GameKit.MVC.Kernel.Attributes;

namespace GameEngine.GameKit.MVC.Kernel {

[ DefaultState(typeof(IdleState)) ]
public class IdleProvider : Provider<IdleProvider> { }

}
