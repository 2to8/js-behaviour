﻿using GameEngine.GameKit.MVC.Contacts;

namespace GameEngine.GameKit.MVC.Kernel.Consts {

public class E_ExitScene : IEvent {

    public int sceneIndex;

}

}
