﻿using GameEngine.GameKit.MVC.Kernel;
using GameEngine.GameKit.MVC.Kernel.Consts;
using GameEngine.GameKit.MVC.Models;

namespace GameEngine.GameKit.MVC.Controllers {

public class AddLevelCommand : Controller<AddLevelCommand> {

    public override void Execute(object data)
    {
        if( data is E_LevelChange level ) {
            GetModel<M_Game>().Level += 1;
        }
    }

}

}
