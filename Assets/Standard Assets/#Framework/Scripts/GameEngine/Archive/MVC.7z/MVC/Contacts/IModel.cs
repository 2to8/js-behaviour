﻿namespace GameEngine.GameKit.MVC.Contacts {

public interface IModel : IApplication {

    int Id { get; set; }

}

}
