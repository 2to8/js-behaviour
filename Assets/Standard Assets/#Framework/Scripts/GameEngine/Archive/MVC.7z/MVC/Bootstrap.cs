﻿using GameEngine.GameKit.MVC.Contacts;
using GameEngine.GameKit.MVC.Controllers;
using GameEngine.GameKit.MVC.Kernel;
using GameEngine.GameKit.MVC.Kernel.Consts;
using GameEngine.Kernel;
using SqlCipher4Unity3D;
using System;
using System.Globalization;
using System.Numerics;
using UniRx.Async;
using UnityEngine;
using UnityEngine.SceneManagement;
using Random = System.Random;

namespace GameEngine.GameKit.MVC {

public class Bootstrap<T> : Provider<T> where T : Bootstrap<T>, IProvider {

    const string DB_FILENAME = "7456765D";
    static SQLiteConnection _db;
    public static string RandomSeed = "A802F98A-A602-4EF6-9AD6-20BEDFB16574";
    public static Random m_random;
    public static Camera MainCamera => Camera.main;

    // Turn a GUID into a string and strip out the '-' characters.
    public static BigInteger huge =>
        BigInteger.Parse(RandomSeed.Replace("-", ""), NumberStyles.AllowHexSpecifier);

    // 基于GUID的Random Seed
    public static Random random => m_random ?? (m_random = new Random((int)(huge % int.MaxValue)));

    // 必须放在 settings 前面
    public static SQLiteConnection knex_db => Core.Connection;
    // {
    //     get {
    //         if( _db == null ) {
    //             _db = new DataService(DB_FILENAME + ".sqlite").Connection();
    //         }
    //
    //         return _db;
    //     }
    //     private set => _db = value;
    // }

    public static TA RandomEnumValue<TA>() where TA : Enum
    {
        var v = Enum.GetValues(typeof(TA));

        return (TA)v.GetValue(random.Next(v.Length));
    }

    public void LoadScene(int level)
    {
        SendEvent<E_ExitScene>(new E_ExitScene { sceneIndex = SceneManager.GetActiveScene().buildIndex, });
        SceneManager.LoadScene(level, LoadSceneMode.Single);
    }

    void OnLevelWasLoaded(int level)
    {
        SendEvent<E_EnterScene>(new E_EnterScene { sceneIndex = level, });
    }

    void OnDestroy()
    {
        /* liteDB */
        //DbModel.WriteToFile();
        knex_db.Close();
        GC.Collect();
        GC.WaitForPendingFinalizers();
    }

    //启动入口

    protected override async UniTask Awake()
    {
        await base.Awake();

        if(transform.GetComponent<IdleProvider>() == null) {
            transform.gameObject.AddComponent<IdleProvider>();
        }

        if(transform.GetComponent<IdleState>()) {
            transform.gameObject.AddComponent<IdleState>();
        }

        DontDestroyOnLoad(gameObject);
        RegisterController<E_StartUp, StartUpCommand>();
    }

    protected override async UniTask Start()
    {
        await base.Start();
        SendEvent<E_StartUp>();
    }

}

}
