﻿using GameEngine.GameKit.MVC.Contacts;
using Plugins.GameEngine.GameKit.Examples;
using System;
using UniRx.Async;
using UnityEngine;

#pragma warning disable 1998

namespace GameEngine.GameKit.MVC.Kernel {

[ Serializable ]
public class ApplicationBase<T> : MonoBase where T : ApplicationBase<T> {

    protected static T m_Instance;
    static GameApp m_GameApp;

    public static GameApp GameViewRoot {
        get {
            if( m_GameApp == null ) {
                m_GameApp = FindObjectOfType<GameApp>();

                if( m_GameApp == null ) {
                    var go = GameObject.Find("/[App]") ?? new GameObject("[App]");
                    m_GameApp = go.AddComponent<GameApp>();
                }
            }

            return m_GameApp;
        }
        private set => m_GameApp = value;
    }

    public static T Instance {
        get {
            if( m_Instance == null ) {
                m_Instance = FindObjectOfType<T>();

                if( m_Instance == null ) {
                    var go = GameViewRoot.transform.Find(typeof(T).Name) ??
                        new GameObject(typeof(T).Name, typeof(T)).transform;

                    go.SetParent(GameViewRoot.transform);
                    m_Instance = go.gameObject.GetComponent<T>() ?? go.gameObject.AddComponent<T>();
                }
            }

            return m_Instance;
        }
    }

    public static T GetInstance() => Instance;

    // get {
    //     lock(_lock) {
    //         if(m_Instance == null && !IsDestroying) {
    //             if(AppRoot == null) {
    //                 AppRoot = new GameObject("App");
    //             }
    //
    //             var go = new GameObject(typeof(T).Name);
    //             go.transform.parent = AppRoot.transform;
    //             m_Instance = go.AddComponent<T>();
    //         }
    //
    //         return m_Instance;
    //     }
    // }
    protected virtual async UniTask Awake()
    {
        await AppLoaderHander;

        if( m_Instance == null ) {
            m_Instance = this as T;
        }

        await OnAwake();
    }

    protected virtual async UniTask OnAwake() { }

    protected virtual async UniTask Update()
    {
        await AppLoaderHander;

        // await OnUpdate();
    }

    // protected virtual async UniTask OnUpdate() { }

    /// <summary>
    ///     提供给 addressable 使用
    /// </summary>
    protected virtual async UniTask Start()
    {
        await AppLoaderHander;
        await OnStart();
    }

    protected virtual async UniTask OnStart() { }
    public override string ToString() => GetType().ToString();

    //注册控制器
    protected void RegisterController(string eventName, Type controllerType)
    {
        Kernel.RegisterController(eventName, controllerType);
    }

    protected void RegisterController<TA>(Type controllerType)
    {
        Kernel.RegisterController(typeof(TA).Name, controllerType);
    }

    protected void RegisterController<TA, TV>()
    {
        Kernel.RegisterController(typeof(TA).Name, typeof(TV));
    }

    protected void RegisterView(IView view)
    {
        Kernel.RegisterView(view);
    }

    //发送事件
    protected void SendEvent(string eventName, object data = null)
    {
        Kernel.SendEvent(eventName, this, data);
    }

    protected void SendEvent(object eventName, object data = null)
    {
        Kernel.SendEvent(eventName.GetType().FullName + "." + eventName, this, data);
    }

    protected void SendEvent<TE>(object data = null)
    {
        Kernel.SendEvent(typeof(TE).Name, this, data);
    }

}

}
