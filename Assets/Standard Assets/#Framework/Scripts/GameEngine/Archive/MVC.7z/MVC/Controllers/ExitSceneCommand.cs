﻿using GameEngine.GameKit.MVC.Kernel;

namespace GameEngine.GameKit.MVC.Controllers {

public class ExitSceneCommand : Controller<ExitSceneCommand> {

    public override void Execute(object data)
    {
        //ObjectPool.Instance.UnspawnAll();
    }

}

}
