﻿namespace GameEngine.GameKit.MVC.Contacts {

public interface IApplication { }

}
