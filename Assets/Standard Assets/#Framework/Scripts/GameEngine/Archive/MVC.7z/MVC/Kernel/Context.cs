﻿using UnityEngine;

namespace GameEngine.GameKit.MVC.Kernel {

[ CreateAssetMenu(fileName = "Context", menuName = "Data/Context", order = 0) ]
public class Context : Model<Context> { }

}
