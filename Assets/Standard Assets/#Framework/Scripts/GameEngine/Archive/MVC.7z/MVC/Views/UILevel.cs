﻿using GameEngine.GameKit.MVC.Kernel;
using GameEngine.GameKit.MVC.Kernel.Attributes;
using GameEngine.GameKit.MVC.Kernel.Consts;
using UniRx.Async;
using UnityEngine.UI;

namespace GameEngine.GameKit.MVC.Views {

public class UILevel : View<UILevel> {

    public Button addLevelButton;
    public Text numberText;
    public Text prenumberText;

    protected override async UniTask Awake()
    {
        await base.Awake();
        numberText.text = 0.ToString();
        prenumberText.text = 0.ToString();
        addLevelButton.onClick.AddListener(OnClickAddLevel);
    }

    public void OnClickAddLevel()
    {
        SendEvent<E_AddLevel>();
    }

    [ Events(typeof(E_LevelChange)) ]
    void OnLevelChange(object sender, object data)
    {
        if( data is E_LevelChange e ) {
            numberText.text = e.level.ToString();
            prenumberText.text = e.level + "%";
        }
    }

}

}
