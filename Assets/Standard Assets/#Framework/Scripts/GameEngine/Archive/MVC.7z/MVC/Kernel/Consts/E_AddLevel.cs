﻿namespace GameEngine.GameKit.MVC.Kernel.Consts {

public class E_AddLevel {

    public int level;

}

}
