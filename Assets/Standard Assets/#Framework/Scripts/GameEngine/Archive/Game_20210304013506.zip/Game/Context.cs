using UnityEngine;

namespace GameCore.Game {

public class Context : MonoBehaviour { }

}
