﻿namespace Plugins.GameEngine.GameKit.Examples.Views {

public enum Nodetype {

    NodeEmpty = 0, Normal, Hard, Restroom, Shop, Unknown, Bonus, LineEmpty, LineLeft, LineRight

}

}
