﻿namespace Plugins.GameEngine.GameKit.Examples.Views.MainView.Attrs {

public class LastVersionAttr : TextBind<string, LastVersionAttr> { }

}
