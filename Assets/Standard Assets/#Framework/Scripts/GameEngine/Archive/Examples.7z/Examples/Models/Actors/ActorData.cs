﻿using GameEngine.GameKit.MVC.Kernel;
using Sirenix.OdinInspector;
using Sirenix.Serialization;
using UnityEngine;

namespace Plugins.GameEngine.GameKit.Examples.Models.Actors {

[ CreateAssetMenu(fileName = "ActorCommon", menuName = "App/ActorCommon", order = 0) ]
public class ActorData : Model<ActorData> {

    [ ShowInInspector, OdinSerialize ]
    public string Title { get; set; }

}

}
