﻿namespace Plugins.GameEngine.GameKit.Examples.Views.MainView.Attrs {

public class TiberiumAttr : TextBind<int, TiberiumAttr> { }

}
