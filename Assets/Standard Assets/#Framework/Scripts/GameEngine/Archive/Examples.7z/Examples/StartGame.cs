﻿using System;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.Events;
using UnityEngine.Serialization;

namespace Plugins.GameEngine.GameKit.Examples {

[ Serializable ]
public class StartGame : MonoBehaviour {

    [ FormerlySerializedAs("LoadGame"), SerializeField ]
    public UnityEvent loadGame;

    [ FormerlySerializedAs("NextScene"), SerializeField ]
    AssetReference nextScene;

    void Start()
    {
        loadGame?.Invoke();
    }

    public void DoStart()
    {
        nextScene?.LoadSceneAsync();
    }

}

}
