﻿using GameEngine.GameKit.MVC.Kernel;
using UnityEngine;
using UnityEngine.AddressableAssets;

namespace Plugins.GameEngine.GameKit.Examples.Views.RaidView {

public class RaidView : Provider<RaidView> {

    [ SerializeField ]
    AssetReference m_Reference;

    public AssetReference Reference { get => m_Reference; set => m_Reference = value; }

}

}
