﻿using GameEngine.GameKit.MVC.Kernel;

namespace Plugins.GameEngine.GameKit.Examples.Models.Cards {

public class CardData : Model<CardData> { }

}
