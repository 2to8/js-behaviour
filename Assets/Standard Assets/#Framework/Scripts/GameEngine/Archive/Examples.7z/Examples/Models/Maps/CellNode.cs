﻿using Plugins.GameEngine.GameKit.Examples.Views;
using Sirenix.OdinInspector;
using Sirenix.Serialization;
using System;

namespace Plugins.GameEngine.GameKit.Examples.Models.Maps {

[ Serializable ]
public class CellNode {

    [ ShowInInspector, OdinSerialize ]
    public bool isCurrent { get; set; }

    [ ShowInInspector, OdinSerialize ]
    public int x { get; set; }

    [ ShowInInspector, OdinSerialize ]
    public int y { get; set; }

    [ ShowInInspector, OdinSerialize ]
    public Nodetype nodetype { get; set; }

}

}
