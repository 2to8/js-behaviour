﻿namespace Plugins.GameEngine.GameKit.Examples.Views.MainView.Attrs {

public class NicknameAttr : TextBind<string, NicknameAttr> { }

}
