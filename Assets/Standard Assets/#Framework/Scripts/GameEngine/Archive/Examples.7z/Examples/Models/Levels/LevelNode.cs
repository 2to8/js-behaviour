﻿using GameEngine.GameKit.MVC.Kernel;
using Plugins.GameEngine.GameKit.Examples.Views.RaidView;
using Sirenix.OdinInspector;
using Sirenix.Serialization;

namespace Plugins.GameEngine.GameKit.Examples.Models.Levels {

public class LevelNode : Model<LevelNode> {

    [ ShowInInspector, OdinSerialize ]
    public int Level { get; set; }

    [ ShowInInspector, OdinSerialize ]
    public int index { get; set; }

    [ ShowInInspector, OdinSerialize ]
    public bool Active { get; set; }

    [ ShowInInspector, OdinSerialize ]
    public RaidType type { get; set; } = RaidType.None;

}

}
