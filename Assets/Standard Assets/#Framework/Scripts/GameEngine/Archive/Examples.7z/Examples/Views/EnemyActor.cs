﻿using GameEngine.GameKit.MVC.Kernel;

namespace Plugins.GameEngine.GameKit.Examples.Views {

public class EnemyActor : View<EnemyActor> { }

}
