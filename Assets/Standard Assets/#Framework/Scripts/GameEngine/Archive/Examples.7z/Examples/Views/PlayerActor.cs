﻿using GameEngine.GameKit.MVC.Kernel;

namespace Plugins.GameEngine.GameKit.Examples.Views {

public class PlayerActor : View<PlayerActor> { }

}
