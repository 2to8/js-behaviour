﻿using GameEngine.GameKit.MVC.Kernel;

namespace Plugins.GameEngine.GameKit.Examples.Models.Levels.AdvLevel {

public class AdvLevelData : Model<AdvLevelData> { }

}
