﻿namespace Plugins.GameEngine.GameKit.Examples.Views.MainView.Attrs {

public class VersionAttr : TextBind<string, VersionAttr> { }

}
