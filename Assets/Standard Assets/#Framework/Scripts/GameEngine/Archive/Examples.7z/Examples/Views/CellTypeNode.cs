﻿using GameEngine.GameKit.MVC.Kernel;

namespace Plugins.GameEngine.GameKit.Examples.Views {

public class CellTypeNode : View<CellTypeNode> {

    public bool isActive;
    public Nodetype nodetype;

}

}
