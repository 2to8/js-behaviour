﻿namespace Plugins.GameEngine.GameKit.Examples.Views.MainView.Attrs {

public class UserDescAttr : TextBind<string, UserDescAttr> { }

}
