﻿using GameEngine.GameKit.MVC.Kernel;
using GameEngine.GameKit.MVC.Kernel.Attributes;

namespace Plugins.GameEngine.GameKit.Examples.Views.RaidView.States {

[ LoadAssets ]
public class NodeActive : StateModel<NodeActive, RaidNode> { }

}
