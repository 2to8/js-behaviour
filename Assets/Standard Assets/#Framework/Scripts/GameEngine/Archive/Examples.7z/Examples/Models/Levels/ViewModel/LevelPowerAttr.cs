﻿namespace Plugins.GameEngine.GameKit.Examples.Models.Levels.ViewModel {

public class LevelPowerAttr : TextBind<int, LevelPowerAttr> { }

}
