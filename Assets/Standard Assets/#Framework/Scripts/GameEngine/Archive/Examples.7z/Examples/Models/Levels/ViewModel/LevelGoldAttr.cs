﻿namespace Plugins.GameEngine.GameKit.Examples.Models.Levels.ViewModel {

public class LevelGoldAttr : TextBind<int, LevelGoldAttr> { }

}
