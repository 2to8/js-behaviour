﻿using Plugins.GameEngine.GameKit.Examples.Views.RaidView;
using System;

namespace Plugins.GameEngine.GameKit.Examples.Models.Levels.RaidLevel {

[ Serializable ]
public class RaidCell {

    public bool Active;
    public bool Display = true;
    public int index;
    public int Stars;
    public RaidType type = RaidType.Normal;

}

}
