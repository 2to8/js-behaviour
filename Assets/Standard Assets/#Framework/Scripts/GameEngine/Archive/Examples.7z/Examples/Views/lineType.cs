﻿namespace Plugins.GameEngine.GameKit.Examples.Views {

public enum LineType { Empty = 0, Left, Right }

}
