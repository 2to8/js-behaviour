﻿using GameEngine.GameKit.MVC.Kernel;

namespace Plugins.GameEngine.GameKit.Examples.Views.RaidView.States {

public class NodeHide : State<NodeHide, RaidNode> { }

}
